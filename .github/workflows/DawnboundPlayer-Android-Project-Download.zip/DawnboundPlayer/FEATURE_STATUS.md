# Dawnbound Player — Feature Status

This report describes source-code checks, not a verified release APK. Android compilation and physical-device testing have not yet been completed.

| Requirement | Current state | Setup / limits |
|---|---|---|
| Search videos | Implemented in source | Real YouTube search needs a user-configured YouTube Data API v3 key. Local sample/custom catalog search works without it. |
| Watch videos | Implemented in source | YouTube playback uses the official embedded player; direct MP4/WebM URLs use the HTML video player. Host restrictions and network availability can prevent playback. |
| Download videos | Partial by design | Android DownloadManager downloads direct HTTP(S) media files the user is authorized to save. YouTube videos are not downloadable through this app. No verified in-app transfer progress/offline media manager yet. |
| Better search | Baseline implemented | YouTube API search results include thumbnails, titles, channels, video/channel/playlist filtering, and newest-sort UI. Advanced filters, API pagination, and production search ranking remain future work. |
| Accounts | Implemented in source; Firebase setup required | Firebase email/password sign-up/sign-in and refresh-token handling. Requires the user's Firebase API key and Project ID. |
| Cloud sync | Implemented in source; Firebase setup required | Firestore document sync for saved videos, likes, history, custom catalog, appearance, download list, and playlists. One document per user; last-writer-wins behavior can overwrite another device's recent changes. Strict Firestore rules required. |
| Playlists | Implemented in source | Create, list, add current video, view and delete playlists. Local state syncs through Firestore when signed in/configured. |
| Adless interface | Implemented | Dawnbound Player itself does not insert ads. YouTube or other hosts may show their own ads; this app does not block them. |
| Customization | Implemented in source | Accent/background colors, dark/light/midnight themes, list/grid/compact layouts, rounded thumbnails, reduced motion. |
| Visual assets | Added | Original local demo thumbnails so the sample feed is attractive even without remote thumbnail loading. |
| APK build | Not verified | GitHub Actions build workflow exists but has not been run from this environment. No finished/verified APK is included. |

## Checks performed
- JavaScript syntax check with `node --check`: passed after the latest UI/cloud-sync edits.
- Interactive browser preview checks: home feed, watch screen layout, settings, account screen, and local search were rendered in a Chromium-based preview.
- ZIP integrity, Android compilation, API calls against a real Firebase project, YouTube live search, and physical-device installation/playback have not been verified.

## Release blockers / production hardening
- Build the APK in GitHub Actions or Android Studio and fix any compiler/build errors.
- Test Firebase Auth and Firestore using a real project and the included `firestore.rules`.
- Harden the WebView JavaScript bridge and store session tokens in secure native storage before public distribution.
- Add Firebase App Check, privacy policy/data deletion flow, crash reporting, download progress, pagination/advanced search, and multi-device conflict handling before calling this production-ready.
