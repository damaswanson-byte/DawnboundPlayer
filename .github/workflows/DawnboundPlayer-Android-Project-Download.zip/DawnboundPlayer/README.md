# Dawnbound Player — Android project

Dawnbound Player is an Android video browser/player with an original dark UI inspired by common video-streaming layouts.

## Current features
- Mobile home feed with sample open videos and category chips.
- Real YouTube video search using the official YouTube Data API v3.
- Search result thumbnails, titles, channel names, search filters, and official YouTube embedded playback.
- API key setup screen inside the app; the key is saved only in this app's local WebView storage.
- Local search suggestions, locally added direct video URLs, likes/saved items, and watch history.
- Direct video file download requests via Android DownloadManager.
- Appearance controls: accent/background colors, dark/light/midnight themes, list/grid/compact layouts, rounded thumbnails, and reduced motion.
- Firebase email/password account creation/sign-in plus Firestore cloud sync for saved videos, likes, history, custom catalog, playlists, download list, and appearance settings after Firebase setup.
- Ad-free app interface: Dawnbound Player itself does not insert third-party ads.
- Search API calls use the Android network stack to avoid `file://` WebView CORS problems.

## Live YouTube search setup
The app needs a YouTube Data API v3 key. This is required for live catalog search; no API key is bundled in this source project.

1. Open Google Cloud Console: https://console.cloud.google.com/
2. Create or select a project.
3. Enable **YouTube Data API v3** for the project.
4. Create an API key in **APIs & Services → Credentials**.
5. Apply appropriate API restrictions and quota limits to the key. An API key stored in a client app can be extracted, so do not use an unrestricted key or treat it as a secret.
6. Install and open Dawnbound Player, tap the gear button, paste the key, and tap **Save API key**.
7. Search for a video. The results should load from YouTube if the key, API access, quota, and network are valid.

Google Cloud Console URL (copy/paste): `https://console.cloud.google.com/`

The app does not include a private or shared API key. Search will fall back to the local sample catalog until the user configures their own key.

## Account setup
Accounts use Firebase Authentication's email/password REST API. No Firebase project or key is bundled with the app.

1. Open Firebase Console: https://console.firebase.google.com/
2. Create a project and add a Web app to it.
3. In **Build → Authentication → Sign-in method**, enable **Email/Password**.
4. In **Build → Firestore Database**, create a database.
5. Copy the **Web API key** and **Project ID** from Project settings → General.
6. In Firestore Rules, use the included `firestore.rules` as a starting point. It allows a signed-in user to read/write only their own `users/{userId}/dawnbound` document. Never use open rules such as `allow read, write: if true`.
7. In Dawnbound Player, enter the API key, Project ID, email, and a password of at least six characters, then choose **Create account** or **Sign in**.
8. Use **Sync now** to pull cloud data. Changes to saved videos, likes, history, custom videos, playlists, download list, and appearance queue for cloud save while signed in.

Cloud sync uses one Firestore document per account. The latest device to sync can overwrite the shared profile document; this is not a conflict-free merge system. Session tokens are stored in app WebView storage, so use a device you trust and sign out on shared devices. Before a public release, move tokens to secure native storage, add Firebase App Check, harden the WebView bridge, test strict Firestore rules, and complete a privacy/security review.

Firebase Console URL (copy/paste): `https://console.firebase.google.com/`

## Playback and downloads
- YouTube search results open in YouTube's official embedded player.
- The app does **not** download YouTube videos. Search access does not grant download rights; use YouTube Premium/offline features or a download offered by the rights holder where available.
- Dawnbound Player has no app-inserted ads, but it cannot guarantee that YouTube or a third-party video host will never show its own ads. It does not block or bypass host advertising.
- DownloadManager supports direct HTTP/HTTPS media-file URLs that the user is authorized to download. Many web-page URLs are not direct media files.
- The download screen records requested downloads; it does not yet provide authoritative transfer progress or a managed in-app offline media database.

## Build an APK
This is an Android Studio project. The source folder is `DawnboundPlayer/`.

1. Install Android Studio on a computer and install a compatible Android SDK (Platform 35 is configured).
2. Open the `DawnboundPlayer` folder as an existing project.
3. Allow Gradle to sync and resolve the Android Gradle Plugin/dependencies.
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. The expected debug APK output is `app/build/outputs/apk/debug/app-debug.apk`.

**Build status in the authoring environment:** APK compilation was not possible because Android SDK/build tools and Gradle were not installed, and network access was unavailable to install them. The expected output path above is not an existing APK unless the build is run successfully. No emulator/device runtime test has been performed.

## Project details
- App name: Dawnbound Player
- Application ID: `com.dawnbound.player`
- Minimum Android: API 26 (Android 8.0)
- Target SDK: 35
- Version: 1.0.0
- Expected build type: debug APK

## Build from a phone using GitHub Actions
This project includes `.github/workflows/build-apk.yml` to build a debug APK in GitHub's cloud runner, so Android Studio is not required on the phone.

1. Download and extract `DawnboundPlayer-Android-Project.zip` using a file manager that supports ZIP extraction.
2. In a browser, open https://github.com/ and create a new repository.
3. Upload the **contents** of the extracted `DawnboundPlayer` folder to the repository root (including `.github/workflows/build-apk.yml`).
4. Open the repository's **Actions** tab and select **Build Dawnbound Player APK**. If asked, enable Actions.
5. Open the completed workflow run, scroll to **Artifacts**, and download `DawnboundPlayer-debug-apk`.
6. Extract the downloaded artifact ZIP to get `app-debug.apk`, then open the APK on your Android phone. Android may ask you to allow installs from that browser or file manager; only install APKs you trust.

The cloud build only succeeds if GitHub can download the Android build dependencies and the project configuration compiles. This workflow has been added but has **not** been executed from this environment, so its remote build result is not yet verified.

## Visual previews
The `previews/` folder contains mobile UI screenshots and a short walkthrough slideshow. These were rendered from the latest HTML interface, not captured from an installed APK. Live YouTube search, Firebase sync, Android build, and device playback remain unverified until configured and tested.
