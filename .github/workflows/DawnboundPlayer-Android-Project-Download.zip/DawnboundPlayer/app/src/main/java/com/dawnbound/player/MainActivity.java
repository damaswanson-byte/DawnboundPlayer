package com.dawnbound.player;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import android.widget.Toast;
import java.net.URL;
import java.net.HttpURLConnection;
import java.net.URLEncoder;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView webView;
    private final ExecutorService networkExecutor = Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new AppBridge(this), "DawnboundAndroid");
        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) ->
            startDownload(url, "video", mimeType));
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void startDownload(String rawUrl, String title, String mimeType) {
        try {
            Uri uri = Uri.parse(rawUrl);
            String scheme = uri.getScheme();
            if (scheme == null || !(scheme.equals("https") || scheme.equals("http"))) {
                Toast.makeText(this, "Only direct HTTP/HTTPS video links can be downloaded.", Toast.LENGTH_LONG).show();
                return;
            }
            String host = uri.getHost();
            if (host == null || host.isEmpty()) throw new IllegalArgumentException("Missing host");
            DownloadManager.Request request = new DownloadManager.Request(uri);
            request.setTitle(title == null || title.trim().isEmpty() ? "Dawnbound video" : title);
            request.setDescription("Downloading for offline playback");
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setAllowedOverMetered(true);
            request.setAllowedOverRoaming(false);
            String guessedMime = (mimeType != null && mimeType.startsWith("video/")) ? mimeType : "video/mp4";
            request.setMimeType(guessedMime);
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, safeFilename(title) + ".mp4");
            DownloadManager manager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            manager.enqueue(request);
            Toast.makeText(this, "Download started. Find it in Downloads when complete.", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Could not start download. Check that the link is a direct video file.", Toast.LENGTH_LONG).show();
        }
    }

    private String safeFilename(String name) {
        String value = (name == null || name.trim().isEmpty()) ? "Dawnbound-Video" : name;
        value = value.replaceAll("[^A-Za-z0-9._-]", "-");
        return value.length() > 70 ? value.substring(0, 70) : value;
    }

    public class AppBridge {
        private final Context context;
        AppBridge(Context context) { this.context = context; }

        @JavascriptInterface public void downloadVideo(String url, String title) {
            runOnUiThread(() -> startDownload(url, title, "video/mp4"));
        }
        @JavascriptInterface public void showMessage(String message) {
            runOnUiThread(() -> Toast.makeText(context, message, Toast.LENGTH_SHORT).show());
        }

        // Firebase email/password authentication over Android's network stack.
        @JavascriptInterface public void firebaseAuth(String action, String email, String password, String apiKey, String requestId) {
            networkExecutor.execute(() -> {
                HttpURLConnection connection = null;
                String result;
                try {
                    String endpoint = "signup".equals(action) ? "signUp" : "signInWithPassword";
                    URL url = new URL("https://identitytoolkit.googleapis.com/v1/accounts:" + endpoint + "?key=" + URLEncoder.encode(apiKey, "UTF-8"));
                    connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("POST");
                    connection.setConnectTimeout(12000);
                    connection.setReadTimeout(15000);
                    connection.setDoOutput(true);
                    connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                    JSONObject payload = new JSONObject();
                    payload.put("email", email);
                    payload.put("password", password);
                    payload.put("returnSecureToken", true);
                    byte[] bytes = payload.toString().getBytes(StandardCharsets.UTF_8);
                    try (java.io.OutputStream output = connection.getOutputStream()) { output.write(bytes); }
                    int status = connection.getResponseCode();
                    InputStream stream = status >= 200 && status < 300 ? connection.getInputStream() : connection.getErrorStream();
                    StringBuilder body = new StringBuilder();
                    try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                        String line;
                        while ((line = reader.readLine()) != null) body.append(line);
                    }
                    result = body.toString();
                } catch (Exception e) {
                    try { result = new JSONObject().put("error", new JSONObject().put("message", "Network error: " + e.getMessage())).toString(); }
                    catch (Exception ignored) { result = "{\"error\":{\"message\":\"Authentication network error\"}}"; }
                } finally {
                    if (connection != null) connection.disconnect();
                }
                deliverAuthResult(requestId, result);
            });
        }

        private void deliverAuthResult(String requestId, String json) {
            String safeId = JSONObject.quote(requestId == null ? "" : requestId);
            String safeJson = JSONObject.quote(json == null ? "{}" : json);
            runOnUiThread(() -> webView.evaluateJavascript("window.onFirebaseAuthResult && window.onFirebaseAuthResult(" + safeId + "," + safeJson + ")", null));
        }

        // Cloud Firestore REST sync for one document per authenticated Firebase user.
        @JavascriptInterface public void firestoreSync(String action, String projectId, String apiKey, String idToken, String userId, String payload, String requestId) {
            networkExecutor.execute(() -> {
                HttpURLConnection connection = null;
                String result;
                try {
                    if (projectId == null || projectId.trim().isEmpty() || userId == null || userId.trim().isEmpty() || idToken == null || idToken.trim().isEmpty()) throw new IllegalArgumentException("Missing Firebase project ID or signed-in session.");
                    String base = "https://firestore.googleapis.com/v1/projects/" + URLEncoder.encode(projectId, "UTF-8") + "/databases/(default)/documents/users/" + URLEncoder.encode(userId, "UTF-8") + "/dawnbound";
                    String query = "?key=" + URLEncoder.encode(apiKey == null ? "" : apiKey, "UTF-8");
                    URL url = new URL(base + ("put".equals(action) ? query + "&updateMask.fieldPaths=payload" : query));
                    connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("get".equals(action) ? "GET" : "PATCH");
                    connection.setConnectTimeout(12000);
                    connection.setReadTimeout(15000);
                    connection.setRequestProperty("Authorization", "Bearer " + idToken);
                    connection.setRequestProperty("Accept", "application/json");
                    if (!"get".equals(action)) {
                        connection.setDoOutput(true);
                        connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                        JSONObject fields = new JSONObject();
                        fields.put("payload", new JSONObject().put("stringValue", payload == null ? "{}" : payload));
                        byte[] bytes = new JSONObject().put("fields", fields).toString().getBytes(StandardCharsets.UTF_8);
                        try (java.io.OutputStream output = connection.getOutputStream()) { output.write(bytes); }
                    }
                    int status = connection.getResponseCode();
                    InputStream stream = status >= 200 && status < 300 ? connection.getInputStream() : connection.getErrorStream();
                    StringBuilder body = new StringBuilder();
                    if (stream != null) try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) { String line; while ((line = reader.readLine()) != null) body.append(line); }
                    if (status == 404 && "get".equals(action)) result = "{\"notFound\":true}";
                    else if (status < 200 || status >= 300) result = new JSONObject().put("error", new JSONObject().put("message", "Firestore HTTP " + status + ": " + body.toString())).toString();
                    else result = "get".equals(action) ? body.toString() : "{\"ok\":true}";
                } catch (Exception e) {
                    try { result = new JSONObject().put("error", new JSONObject().put("message", "Cloud sync error: " + e.getMessage())).toString(); }
                    catch (Exception ignored) { result = "{\"error\":{\"message\":\"Cloud sync error\"}}"; }
                } finally { if (connection != null) connection.disconnect(); }
                deliverCloudResult(requestId, result);
            });
        }

        @JavascriptInterface public void firebaseRefresh(String apiKey, String refreshToken, String requestId) {
            networkExecutor.execute(() -> {
                HttpURLConnection connection = null;
                String result;
                try {
                    URL url = new URL("https://securetoken.googleapis.com/v1/token?key=" + URLEncoder.encode(apiKey, "UTF-8"));
                    connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("POST"); connection.setConnectTimeout(12000); connection.setReadTimeout(15000); connection.setDoOutput(true);
                    connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                    byte[] body = ("grant_type=refresh_token&refresh_token=" + URLEncoder.encode(refreshToken, "UTF-8")).getBytes(StandardCharsets.UTF_8);
                    try (java.io.OutputStream output = connection.getOutputStream()) { output.write(body); }
                    int status = connection.getResponseCode(); InputStream stream = status >= 200 && status < 300 ? connection.getInputStream() : connection.getErrorStream();
                    StringBuilder response = new StringBuilder(); if (stream != null) try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) { String line; while ((line = reader.readLine()) != null) response.append(line); }
                    result = response.toString();
                } catch (Exception e) { try { result = new JSONObject().put("error", new JSONObject().put("message", "Session refresh error: " + e.getMessage())).toString(); } catch (Exception ignored) { result = "{\"error\":{\"message\":\"Session refresh error\"}}"; } }
                finally { if (connection != null) connection.disconnect(); }
                String safeId = JSONObject.quote(requestId == null ? "" : requestId); String safeJson = JSONObject.quote(result == null ? "{}" : result);
                runOnUiThread(() -> webView.evaluateJavascript("window.onFirebaseRefreshResult && window.onFirebaseRefreshResult(" + safeId + "," + safeJson + ")", null));
            });
        }

        private void deliverCloudResult(String requestId, String json) {
            String safeId = JSONObject.quote(requestId == null ? "" : requestId); String safeJson = JSONObject.quote(json == null ? "{}" : json);
            runOnUiThread(() -> webView.evaluateJavascript("window.onCloudSyncResult && window.onCloudSyncResult(" + safeId + "," + safeJson + ")", null));
        }

        // Uses Android's network stack so local-file WebView CORS restrictions do not block API calls.
        @JavascriptInterface public void searchYoutube(String query, String type, String apiKey, String requestId) {
            if (query == null || query.trim().isEmpty() || apiKey == null || apiKey.trim().isEmpty()) {
                deliverSearchResult(requestId, "{\"error\":{\"message\":\"Search query or API key is missing.\"}}");
                return;
            }
            networkExecutor.execute(() -> {
                HttpURLConnection connection = null;
                String result;
                try {
                    String safeType = ("channel".equals(type) || "playlist".equals(type)) ? type : "video";
                    String address = "https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=25&safeSearch=moderate&type="
                        + URLEncoder.encode(safeType, "UTF-8") + "&q=" + URLEncoder.encode(query, "UTF-8")
                        + "&key=" + URLEncoder.encode(apiKey, "UTF-8");
                    connection = (HttpURLConnection) new URL(address).openConnection();
                    connection.setRequestMethod("GET");
                    connection.setConnectTimeout(12000);
                    connection.setReadTimeout(15000);
                    connection.setRequestProperty("Accept", "application/json");
                    int status = connection.getResponseCode();
                    InputStream stream = status >= 200 && status < 300 ? connection.getInputStream() : connection.getErrorStream();
                    StringBuilder body = new StringBuilder();
                    try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                        String line;
                        while ((line = reader.readLine()) != null) body.append(line);
                    }
                    result = body.toString();
                } catch (Exception e) {
                    try { result = new JSONObject().put("error", new JSONObject().put("message", "Network error: " + e.getMessage())).toString(); }
                    catch (Exception ignored) { result = "{\"error\":{\"message\":\"Network error\"}}"; }
                } finally {
                    if (connection != null) connection.disconnect();
                }
                deliverSearchResult(requestId, result);
            });
        }

        private void deliverSearchResult(String requestId, String json) {
            String safeId = JSONObject.quote(requestId == null ? "" : requestId);
            String safeJson = JSONObject.quote(json == null ? "{}" : json);
            runOnUiThread(() -> webView.evaluateJavascript("window.onYoutubeSearchResult && window.onYoutubeSearchResult(" + safeId + "," + safeJson + ")", null));
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
