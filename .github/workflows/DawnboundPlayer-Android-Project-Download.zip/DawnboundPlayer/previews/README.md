# Dawnbound Player visual preview

These screenshots and `DawnboundPlayer-Walkthrough-Preview.mp4` were captured from the latest HTML interface in a Chromium-based browser at a mobile viewport. They demonstrate the home, player, search, customization, and account/cloud-sync screens.

They are **UI previews**, not screenshots/video captured from an installed Android APK. YouTube live search and Firebase sync were not connected during the capture. The watch screen preview uses a sample media URL and its playback spinner is not proof of successful network playback. The APK has not yet been compiled or device-tested.
